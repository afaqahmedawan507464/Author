function hamburgermenufunction() {
    let element = document.getElementById("menbarmobile");
    element.classList.toggle("mobilemenudropdownhide");
}

// animated hamburger icons function

function changeposition(x){
    x.classList.toggle("change");
}
