// let i;
// let clickme = document.getElementsByClassName("headerdesktopmenu nav ul span li a");
// for(i = 0;i < clickme.length;i++){
//     clickme[i].addEventListener("click" , function(){
//         let currentclass = document.getElementsByClassName("active");
//         if(currentclass > 0){
//             currentclass[0].className = currentclass[0].className.replace(" active","");
//         }
//         this.className += " active";
//     });
// }